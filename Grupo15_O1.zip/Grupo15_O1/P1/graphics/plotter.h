#include <string.h>
#include <unistd.h>  //para execv
#include <stdio.h>
#include <stdlib.h>
int dibujar(void);
 

