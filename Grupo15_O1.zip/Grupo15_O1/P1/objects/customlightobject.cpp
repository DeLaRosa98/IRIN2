#include "customlightobject.h"

bool operator==(const light_color_t &lhs, const light_color_t &rhs)
{
	return lhs.red == rhs.red && lhs.green == rhs.green && lhs.blue == rhs.blue;
}

bool operator!=(const light_color_t &lhs, const light_color_t &rhs)
{
	return lhs.red != rhs.red || lhs.green != rhs.green || lhs.blue != rhs.blue;
}

CCustomLightObject::CCustomLightObject(const char *pch_name) : CGeometry(pch_name)
{
	m_dCenter.x = 0.0;
	m_dCenter.y = 0.0;
	m_fIntRadius = 0.0;
	m_fExtRadius = 0.0;
	m_color = {1.0, 1.0, 0.0};

	m_nActivation = true;
}

CCustomLightObject::~CCustomLightObject()
{
}

void CCustomLightObject::SetColor(light_color_t color)
{
	m_color = color;
}

light_color_t CCustomLightObject::GetColor()
{
	return m_color;
}

void CCustomLightObject::SetHeight(float fHeight)
{
	m_fHeight = fHeight;
}

void CCustomLightObject::GetHeight(float *fHeight)
{
	(*fHeight) = m_fHeight;
}

void CCustomLightObject::SetCenter(dVector2 dCenter)
{
	m_dCenter = dCenter;
}

void CCustomLightObject::GetCenter(dVector2 *dCenter)
{
	(*dCenter) = m_dCenter;
}

void CCustomLightObject::SetIntRadius(float fRadius)
{
	m_fIntRadius = fRadius;
}

void CCustomLightObject::GetIntRadius(float *fRadius)
{
	(*fRadius) = m_fIntRadius;
}

void CCustomLightObject::SetExtRadius(float fRadius)
{
	m_fExtRadius = fRadius;
}

void CCustomLightObject::GetExtRadius(float *fRadius)
{
	(*fRadius) = m_fExtRadius;
}

void CCustomLightObject::Switch(int n_value)
{
	if (n_value == 0)
		m_nActivation = false;
	else
		m_nActivation = true;
}

int CCustomLightObject::GetStatus(void)
{
	return m_nActivation;
}

void CCustomLightObject::Reset(void)
{
	m_nActivation = true;
}

int CCustomLightObject::GetTiming(unsigned int n_step_number)
{
	//if ( (n_step_number % 400) == 0 )
	//m_nActivation = true;

	//printf("Act: Yellow: %d\n", m_nActivation);

	/* Create sequence */
	//if ( !(n_step_number % 500) )
	//{
	///* toggle light */
	//m_nActivation ^= 0x1;
	//}

	/* default return true */
	return m_nActivation;
}
