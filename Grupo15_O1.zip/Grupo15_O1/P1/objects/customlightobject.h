#ifndef CUSTOMLIGHTOBJECT_H_
#define CUSTOMLIGHTOBJECT_H_

/******************************************************************************/
/******************************************************************************/

#include "geometry.h"

typedef struct light_color
{
	double red;
	double green;
	double blue;
} light_color_t;

bool operator==(const light_color_t &lhs, const light_color_t &rhs);
bool operator!=(const light_color_t &lhs, const light_color_t &rhs);

class CCustomLightObject;

/******************************************************************************/
/******************************************************************************/

class CCustomLightObject : public CGeometry
{
  public:
	CCustomLightObject(const char *pch_name);
	~CCustomLightObject();

	static light_color_t red()
	{
		return {1.0, 0.0, 0.0};
	}
	static light_color_t green()
	{
		return {0.0, 1.0, 0.0};
	}
	static light_color_t blue()
	{
		return {0.0, 0.0, 1.0};
	}
	static light_color_t yellow()
	{
		return {1.0, 1.0, 0.0};
	}

	void SetColor(light_color_t color);
	light_color_t GetColor();

	void SetHeight(float fHeight);
	void GetHeight(float *fHeight);

	void SetCenter(dVector2 dCenter);
	void GetCenter(dVector2 *dCenter);

	void SetIntRadius(float fRadius);
	void GetIntRadius(float *fRadius);

	void SetExtRadius(float fRadius);
	void GetExtRadius(float *fRadius);

	void Switch(int n_value);
	int GetStatus(void);

	int GetTiming(unsigned int n_step_number);

	void Reset(void);

  private:
	light_color_t m_color;
	dVector2 m_dCenter;
	float m_fIntRadius;
	float m_fExtRadius;
	float m_fHeight;

	int m_nActivation;
};

/******************************************************************************/
/******************************************************************************/

#endif
