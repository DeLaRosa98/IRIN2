function [avoid,runaway,hunt,navigate,explore] = readTasks(filename)
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here
[time,active,direction] = readTaskBrute(filename)
for i = 1:length(time)
    av
end 
end

