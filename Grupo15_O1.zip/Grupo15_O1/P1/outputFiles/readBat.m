%Read Batteries
[t1 bat0] = readBatfcn('bateria_P0');
[t2 bat1] = readBatfcn('bateria_P1');
[t3 bat2] = readBatfcn('bateria_P2');
[t4 bat3] = readBatfcn('bateria_P3');
[t5 bat4] = readBatfcn('bateria_H4');
[t6 bat5] = readBatfcn('bateria_C5');

plot(t1,bat0,t2,bat1,t3,bat2,t4,bat3,t5,bat4,t6,bat5);
huntThres = 0.65 * ones(1,213);
hold on;
plot(huntThres)
legend("P0","P1","P2","P3","H4","C5","HuntThreshold");
hold off;

