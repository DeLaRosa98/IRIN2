#ifndef CUSTOMLIGHTSENSOR_H_
#define CUSTOMLIGHTSENSOR_H_

/******************************************************************************/
/******************************************************************************/

class CCustomLightSensor;

/******************************************************************************/
/******************************************************************************/

#include "sensor.h"
#include "arena.h"

#include "customlightobject.h"

#define NUM_LIGHT_SENSORS 8

/******************************************************************************/
/******************************************************************************/

class CCustomLightSensor : public CSensor
{
  public:
	CCustomLightSensor(const char *pch_name, double f_rangeLightSensor,int m_functionSensor);
	~CCustomLightSensor();

	// Get the sensor type:
	virtual unsigned int GetType();

	//Manage color
	light_color_t GetColor();
	void SetColor(light_color_t color);

	//Compute Readings
	double *ComputeSensorReadings(CEpuck *p_pcEpuck, CSimulator *p_pcSimulator);

	//Get Reading. Returns if hot spot is visible.
	double *GetSensorReading(CEpuck *p_pcEpuck);

	double GetMaxRange(void);
	const double *GetSensorDirections(void);

	static unsigned int SENSOR_NUMBER;

  protected:
	CArena *m_pcArena;
	CEpuck *m_pcEpuck;

	int m_functionSensor;
	light_color_t m_Color;
	double m_fRangeLightSensor;
	static double m_fLightSensorDir[NUM_LIGHT_SENSORS];
};

/******************************************************************************/
/******************************************************************************/

#endif
