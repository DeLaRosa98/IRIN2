#include <stdint.h>
#include <cstdio>

namespace dataStructures{

    enum box_t{
        ERROR,
        UNEXPLORED,
        EMPTY,
        WALL,
        MYSELF,
        OBJECT,
    };

    class ArenaMap
    {
        private:
            box_t** grid;
            size_t xMax;
            size_t yMax;
            void FillMap(box_t** _grid, size_t x, size_t y);
            box_t** CreateGrid(size_t x, size_t y);
            void DeleteGrid(box_t** grid,size_t y);
        public:
            ArenaMap(const size_t x,const size_t y);
            void AddBox(size_t x,size_t y,box_t type);
            box_t GetBox(size_t x,size_t y);
            void ExpandMap();
            void ExpandMap(const size_t new_x,const size_t new_y);
            void PrintMap();
            ~ArenaMap();
    };

}
