#include "aStar.hpp"
#include <stdio.h>

#define ROW 9 
#define COL 10 

using namespace std; 
using namespace dataStructures;
using namespace AuxAlgorithms;

int main(){
    ArenaMap myMap(10,9);
    myMap.PrintMap();
    box_t grid[ROW][COL] = 
    { 
        { EMPTY, WALL, EMPTY, EMPTY, EMPTY, EMPTY, WALL, EMPTY, EMPTY, EMPTY }, 
        { EMPTY, EMPTY, EMPTY, WALL, EMPTY, EMPTY, EMPTY, WALL, EMPTY, EMPTY }, 
        { EMPTY, EMPTY, EMPTY, WALL, EMPTY, EMPTY, WALL, EMPTY, WALL, EMPTY }, 
        { WALL, WALL, EMPTY, WALL, EMPTY, WALL, WALL, WALL, WALL, EMPTY }, 
        { EMPTY, EMPTY, EMPTY, WALL, EMPTY, EMPTY, EMPTY, WALL, EMPTY, WALL }, 
        { EMPTY, WALL, EMPTY, EMPTY, EMPTY, EMPTY, WALL, EMPTY, WALL, WALL }, 
        { EMPTY, WALL, WALL, WALL, WALL, EMPTY, WALL, WALL, WALL, EMPTY }, 
        { EMPTY, WALL, EMPTY, EMPTY, EMPTY, EMPTY, WALL, EMPTY, EMPTY, EMPTY }, 
        { EMPTY, EMPTY, EMPTY, WALL, WALL, WALL, EMPTY, WALL, WALL, EMPTY } 
    };
    
    box_t** theGoodGrid = new box_t*[ROW];
    for(int i = 0; i < ROW; ++i)
        theGoodGrid[i] = new box_t[COL]; 
    for(int r = 0; r < ROW; r++){
        for(int c = 0; c < COL; c++){
           theGoodGrid[r][c] = grid[r][c]; 
        }
    }
    for(int r = 0; r < ROW; r++){
        for(int c = 0; c < COL; c++){
           myMap.AddBox(c,r,grid[r][c]); 
        }
    }
    // Source is the left-most bottom-most corner 
    Pair src = std::make_pair(8, 0); 
  
    // Destination is the left-most top-most corner 
    Pair dest = std::make_pair(0, 0);
     
    AStar algo(theGoodGrid,COL,ROW);
    myMap.PrintMap();
    //first -> y
    //second -> x
    std::vector<Pair> path = algo.aStarSearch(src, dest);
    for(auto casilla : path){
        myMap.AddBox(casilla.second,casilla.first,MYSELF);
    }
    myMap.PrintMap();
    return 0;
}