#include "arenaMap.h"
#include <cstdio>

using namespace dataStructures;

ArenaMap::ArenaMap(const size_t x,const size_t y){
    grid  = CreateGrid(x,y);
    xMax = x;
    yMax = y;
    FillMap(grid,x,y);
    printf("Created S\n");
}

box_t** ArenaMap::CreateGrid(size_t x, size_t y){
    box_t** grid = new box_t*[y];
    for(int i = 0; i < y; ++i)
        grid[i] = new box_t[x];
    return grid;
}

void ArenaMap::DeleteGrid(box_t** grid,size_t y){
    size_t i = 0;
    for(; i < y; i++){
        delete grid[i];
    }
    delete grid;
}

void ArenaMap::FillMap(box_t** _grid, size_t x, size_t y){
    size_t i = 0;
    size_t j = 0;
    for(;i < y; i++){
        for(j = 0; j < x; j++){
            _grid[i][j] = UNEXPLORED;        
        }
        
    }
}

void ArenaMap::AddBox(size_t x,size_t y,box_t type){
    if(x >= xMax || y >= yMax){
        printf("Add map error \n");
        return;
    }
    grid[y][x] = type;
}

box_t ArenaMap::GetBox(size_t x, size_t y){
    if(x >= xMax || y >= yMax){
        printf("get box map error \n");
        return ERROR;
    }
    return grid[y][x];
}

void ArenaMap::ExpandMap(){
    ExpandMap(xMax+2,yMax+2);
}

void ArenaMap::ExpandMap(size_t newX, size_t newY){
    if(newX <= xMax || newY <= yMax){
        return;
    }
    box_t** newGrid = CreateGrid(newX,newY);
    FillMap(newGrid,newX,newY);
    size_t i = 0;
    size_t j = 0;
    size_t refX = (newX-xMax)/2;
    size_t refY = (newY-yMax)/2;
    for(;i < yMax; i++){
        for(j = 0; j < xMax; j++){
            newGrid[refY+i][refX+j] = GetBox(j,i);
        }
    }
    //Swap items
    DeleteGrid(grid,yMax);
    yMax = newY;
    xMax = newX;
    grid = newGrid;
}

void ArenaMap::PrintMap(){
    size_t i = 0;
    size_t j = 0;
    printf("-/-/-/-/-/-/-/-/-/-/-/-/ \n");
    for(;i < yMax; i++){
        for(j = 0; j < xMax; j++){
            switch(GetBox(j,i)){
                case UNEXPLORED:
                    printf("?");
                    break;
                case EMPTY:
                    printf("*");
                    break;
                case WALL:
                    printf("#");
                    break;
                case MYSELF:
                    printf("@");
                    break;
                case OBJECT:
                    printf("O");
                    break;
            }
        }
        printf("\n");
    }
    printf("-/-/-/-/-/-/-/-/-/-/-/-/ \n");
}

box_t** ArenaMap::GetGrid(){
    return grid;
}


ArenaMap::~ArenaMap()
{
    printf("Deleted \n");
    DeleteGrid(grid,yMax);
}
