/******************************************************************************/
/******************************************************************************/
#ifndef BASEROBOT_H_
#define BASEROBOT_H_

#include "controller.h"
#include <utility>
#include <vector>
#include "aStar.hpp"


/******************************************************************************/
/******************************************************************************/

typedef struct robotState
{
	bool active;
	double direction;
	double priority;
} robotState_t;

namespace utilities
{
typedef struct position
{
	double x;
	double y;
	double orientation;
} position_t;
typedef struct wheelSpeed
{
	double left;
	double right;
} wheelSpeed_t;
} // namespace utilities

class baseRobot : public CController
{
  public:
	baseRobot(const char *pch_name, CEpuck *pc_epuck, int n_write_to_file, CCustomLightObject *light);
	~baseRobot();
	void SimulationStep(unsigned n_step_number, double f_time, double f_step_interval);

  private:
	double normalizeAngle(double angle);
	void promediatePriorities(std::vector<robotState_t> *robotTasks);
	utilities::wheelSpeed_t coordinateTasks(std::vector<robotState_t> *robotTasks);
	double getTargetAngle(int size, double *data, const double *directions, double *max);
	void CalcPosition();
	void moveSelfLight();

  protected:
	virtual robotState_t Avoid();
	virtual robotState_t Hunt();
	virtual robotState_t Explore();
	virtual robotState_t RunAway();
	virtual robotState_t Navigate();
	virtual void checkDied();
	virtual void Eat();

	bool CheckPredatorDistance();
	bool CheckBattery();

	void setPreyColor(light_color_t color);
	void setHunterColor(light_color_t color);

	utilities::position_t pos;

	CEpuck *m_pcEpuck;
	//Sensors
	CWheelsActuator *m_acWheels;
	CEpuckProximitySensor *m_seProx;
	CCustomLightSensor *m_seCustomLightEat;
	CCustomLightSensor *m_seCustomLightRunAway;
	CRealLightSensor *m_seLight;
	CRealBlueLightSensor *m_seBlueLight;
	CRealRedLightSensor *m_seRedLight;
	CContactSensor *m_seContact;
	CGroundSensor *m_seGround;
	CGroundMemorySensor *m_seGroundMemory;
	CBatterySensor *m_seBattery;
	CBlueBatterySensor *m_seBlueBattery;
	CRedBatterySensor *m_seRedBattery;
	CEncoderSensor *m_seEncoder;
	CCompassSensor *m_seCompass;
	CCustomBatterySensor *m_seCustomBatterySensor;

	bool dieInhibitor;
	bool runAwayInhibitor;
	bool hasHunted;
	bool eating;
	int dieCount;
	/*Robot Parameters*/
	CCustomLightObject *robotLight;
	light_color_t preyColor;
	light_color_t hunterColor;

	double robotSpeed;
	double proximitySensorThreshold;
	double runAwayThreshold;
	double checkDiedThreshold;
	double eatThreshold;
	double huntThreshold;
	//Maping structures
	dataStructures::ArenaMap* arenaMap;
	AuxAlgorithms::AStar* starA;

	int m_nWriteToFile;
};

#endif
