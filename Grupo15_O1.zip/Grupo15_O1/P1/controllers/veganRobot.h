/******************************************************************************/
/******************************************************************************/
#ifndef VEGANROBOT_H_
#define VEGANROBOT_H_

#include "baseRobot.h"


/******************************************************************************/
/******************************************************************************/

class veganRobotController : public baseRobot
{
public:

    veganRobotController (const char *pch_name, CEpuck *pc_epuck, int n_write_to_file, CCustomLightObject *light);
    ~veganRobotController();

private:

};

#endif