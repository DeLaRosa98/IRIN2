/******************* INCLUDES ******************/
/***********************************************/

/******************** General ******************/
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <sys/time.h>
#include <iostream>

/******************** Simulator ****************/
/******************** Sensors ******************/
#include "epuckproximitysensor.h"
#include "contactsensor.h"
#include "reallightsensor.h"
#include "realbluelightsensor.h"
#include "realredlightsensor.h"
#include "groundsensor.h"
#include "groundmemorysensor.h"
#include "batterysensor.h"
#include "bluebatterysensor.h"
#include "redbatterysensor.h"
#include "encodersensor.h"
#include "compasssensor.h"
#include "customlightsensor.h"
#include "custombatterysensor.h"

/******************** Actuators ****************/
#include "wheelsactuator.h"

/******************** Controller **************/
#include "veganRobot.h"

extern gsl_rng* rng;
extern long int rngSeed;

using namespace std;



veganRobotController::veganRobotController (const char *pch_name, CEpuck *pc_epuck, int n_write_to_file, CCustomLightObject *light) : baseRobot (pch_name, pc_epuck, n_write_to_file, light)
{
	this->setPreyColor(CCustomLightObject::green());
	this->setHunterColor(CCustomLightObject::red());
	
}
/******************************************************************************/
/******************************************************************************/

veganRobotController::~veganRobotController()
{
}


/******************************************************************************/
/******************************************************************************/



/******************************************************************************/
/******************************************************************************/

