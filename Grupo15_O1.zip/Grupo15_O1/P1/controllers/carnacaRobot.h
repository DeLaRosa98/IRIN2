/******************************************************************************/
/******************************************************************************/
#ifndef CARNACAROBOT_H_
#define CARNACAROBOT_H_

#include "baseRobot.h"



/******************************************************************************/
/******************************************************************************/

class carnacaRobotController : public baseRobot
{
public:

    carnacaRobotController (const char *pch_name, CEpuck *pc_epuck, int n_write_to_file, CCustomLightObject *light);
    ~carnacaRobotController();
 	robotState_t RunAway();
    void checkDied();
private:
    
};

#endif