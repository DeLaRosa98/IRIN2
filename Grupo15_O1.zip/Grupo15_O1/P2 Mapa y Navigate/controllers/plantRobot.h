/******************************************************************************/
/******************************************************************************/
#ifndef PLANTROBOT_H_
#define PLANTROBOT_H_

#include "baseRobot.h"



/******************************************************************************/
/******************************************************************************/

class plantRobotController : public baseRobot
{
public:

    plantRobotController (const char *pch_name, CEpuck *pc_epuck, int n_write_to_file, CCustomLightObject *light);
    ~plantRobotController();
    robotState_t Hunt();
private:
};

#endif