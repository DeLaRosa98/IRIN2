#include "arenaMap.h"
#include <cstdio>
#include <cmath>

using namespace dataStructures;

ArenaMap::ArenaMap(const size_t x, const size_t y, double _mapStep)
{
	grid = CreateGrid(x, y);
	xMax = x;
	yMax = y;
	mapStep = _mapStep;
	origin = std::pair<int, int>(0, 0);
	FillMap(grid, x, y);
	printf("Created S\n");
}

box_t **ArenaMap::CreateGrid(size_t x, size_t y)
{
	box_t **grid = new box_t *[y];
	for (int i = 0; i < y; ++i)
		grid[i] = new box_t[x];
	return grid;
}

void ArenaMap::DeleteGrid(box_t **grid, size_t y)
{
	size_t i = 0;
	for (; i < y; i++)
	{
		delete grid[i];
	}
	delete grid;
}

void ArenaMap::FillMap(box_t **_grid, size_t x, size_t y)
{
	size_t i = 0;
	size_t j = 0;
	for (; i < y; i++)
	{
		for (j = 0; j < x; j++)
		{
			_grid[i][j] = UNEXPLORED;
		}
	}
}

void ArenaMap::AddBox(int x, int y, box_t type)
{
	int xExpand = 0;
	int yExpand = 0;
	int newXPos = 0;
	int newYPos = 0;
	if (x < 0)
	{
		xExpand = x;
	}
	else if (x >= xMax)
	{
		xExpand = (x - xMax) + 1;
		newXPos = x;
	}
	if (y < 0)
	{
		yExpand = y;
	}
	else if (y >= yMax)
	{
		yExpand = (y - yMax) + 1;
		newYPos = y;
	}
	//printf("X:%d Y:%d NEWX:%d NEWY:%d expX:%d expY:%d \n",x,y,newXPos,newYPos,xExpand,yExpand);
	if (xExpand != 0 || yExpand != 0)
	{

		ExpandMap(xExpand, yExpand);
	}
	else
	{
		newXPos = x;
		newYPos = y;
	}
	//printf("xpos %d ypos %d SIZE %d %d\n",newXPos,newYPos,xMax,yMax);
	grid[newYPos][newXPos] = type;
}

void ArenaMap::AddBoxAbsolute(double x, double y, box_t type)
{
	int xDiscrete = ((int)std::round(x / mapStep)) + origin.first;
	int yDiscrete = ((int)std::round(y / mapStep)) + origin.second;
	//if (type == MYSELF)
		//printf("X: %f %d, Y: %f %d\n", x, xDiscrete, y, yDiscrete);
	AddBox(xDiscrete, yDiscrete, type);
}

box_t ArenaMap::GetBox(size_t x, size_t y)
{
	if (x >= xMax || y >= yMax)
	{
		//printf("get box map error \n");
		return ERROR;
	}
	return grid[y][x];
}

void ArenaMap::ExpandMap()
{
	ExpandMap(2, 2);
}

void ArenaMap::ExpandMap(int newX, int newY)
{
	if (newX == 0 && newY == 0)
	{
		return;
	}
	box_t **newGrid = CreateGrid(xMax + abs(newX), yMax + abs(newY));
	box_t **tstGrid;
	FillMap(newGrid, xMax + abs(newX), yMax + abs(newY));
	int i = 0;
	int j = 0;
	int insertX = 0;
	int insertY = 0;

	for (; i < yMax; i++)
	{
		for (j = 0; j < xMax; j++)
		{
			if (newX < 0)
			{
				insertX = -newX + j;
			}
			else
			{
				insertX = j;
			}
			if (newY < 0)
			{
				insertY = -newY + i;
			}
			else
			{
				insertY = i;
			}
			//printf("INSERT %d %d ,TYPE %d %d %d\n",insertX,insertY,GetBox(j,i),j,i);
			newGrid[insertY][insertX] = GetBox(j, i);
		}
	}
	//Swap items
	tstGrid = grid;
	yMax += abs(newY);
	xMax += abs(newX);
	if (newX < 0)
	{
		origin.first += abs(newX);
	}
	if (newY < 0)
	{
		origin.second += abs(newY);
	}
	grid = newGrid;
	DeleteGrid(tstGrid, yMax - abs(newY));
	//PrintMap();
}

size_t ArenaMap::GetXMax()
{
	return xMax;
}

size_t ArenaMap::GetYMax()
{
	return yMax;
}

double ArenaMap::GetStep()
{
	return mapStep;
}

void ArenaMap::PrintMap()
{
	size_t i = 0;
	size_t j = 0;
	printf("-/-/-/-/-/-/-/-/-/-/-/-/ \n");
	for (; i < yMax; i++)
	{
		for (j = 0; j < xMax; j++)
		{
			switch (GetBox(j, i))
			{
			case UNEXPLORED:
				printf("?");
				break;
			case EMPTY:
				printf("*");
				break;
			case WALL:
				printf("#");
				break;
			case MYSELF:
				printf("@");
				break;
			case OBJECT:
				printf("O");
				break;
            case LIGHT:
            	printf("L");
				break;
			}
		}
		printf("\n");
	}
	printf("-/-/-/-/-/-/-/-/-/-/-/-/ \n");
}

box_t **ArenaMap::GetGrid()
{
	return grid;
}

std::pair<double, double> ArenaMap::GetPositionAbsolute(int x, int y)
{
	std::pair<double, double> position;
	position.first = (x - origin.first) * mapStep;
	position.second = (y - origin.second) * mapStep;
	return position;
}

std::vector<std::pair<int, int>> ArenaMap::GetObjectsPositions(box_t object)
{
	size_t i = 0;
	size_t j = 0;
	std::vector<std::pair<int, int>> pointList;
	for (; i < yMax; i++)
	{
		for (j = 0; j < xMax; j++)
		{
			if (grid[i][j] == object)
				pointList.push_back(std::pair<int, int>((int)j, (int)i));
		}
	}
	return pointList;
}

std::vector<std::pair<double, double>> ArenaMap::GetObjectsPositionsAbsolute(box_t object)
{
	std::vector<std::pair<int, int>> positions = GetObjectsPositions(object);
	std::vector<std::pair<double, double>> positionsAbsolute;

	for (std::pair<int, int> currentPosition : positions)
	{
		std::pair<double, double> position;
		position.first = (currentPosition.first - origin.first) * mapStep;
		position.second = (currentPosition.second - origin.second) * mapStep;
		positionsAbsolute.push_back(position);
	}

	return positionsAbsolute;
}

ArenaMap::~ArenaMap()
{
	printf("Deleted \n");
	DeleteGrid(grid, yMax);
}
