/******************* INCLUDES ******************/
/***********************************************/

/******************** General ******************/
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <sys/time.h>
#include <iostream>
#include <cmath>
#include <string.h>

/******************** Simulator ****************/
/******************** Sensors ******************/
#include "epuckproximitysensor.h"
#include "contactsensor.h"
#include "customlightsensor.h"
#include "reallightsensor.h"
#include "realbluelightsensor.h"
#include "realredlightsensor.h"
#include "groundsensor.h"
#include "groundmemorysensor.h"
#include "batterysensor.h"
#include "bluebatterysensor.h"
#include "redbatterysensor.h"
#include "encodersensor.h"
#include "compasssensor.h"
#include "custombatterysensor.h"

/******************** Actuators ****************/
#include "wheelsactuator.h"

/******************** Controller **************/
#include "baseRobot.h"

#define PRINT_ROBOT_STATE(x) cout << "ACTIVE " << x.active << " DIRECTION " << x.direction << " PRIORITY " << x.priority << endl;
#define ERROR_DIRECTION 0.05
#define ERROR_POSITION 0.02
#define DIE_ERROR 0.02

extern gsl_rng *rng;
extern long int rngSeed;

baseRobot::baseRobot(const char *pch_name, CEpuck *pc_epuck, int n_write_to_file, CCustomLightObject *light) : CController(pch_name, pc_epuck), robotLight(light)
{
	/* Set Write to File */
	m_nWriteToFile = n_write_to_file;
	pos.x = 0;
	pos.y = 0;
	pos.orientation = 0;
	proximitySensorThreshold = 0.3;
	runAwayThreshold = 0.1;
	checkDiedThreshold = 0.2;
	eatThreshold = 0.95;
	robotSpeed = 500;
	dieInhibitor = false;
	runAwayInhibitor = false;
	navigating = false;
	huntThreshold = 0.65;
	dieCount = 0;
	target = nullptr;
	//Map structure
	arenaMap = new dataStructures::ArenaMap(1, 1, 0.05);
	arenaMap->AddBox(0, 0, MYSELF);
	starA = nullptr;
	/* Set epuck */
	m_pcEpuck = pc_epuck;
	/* Set Wheels */
	m_acWheels = (CWheelsActuator *)m_pcEpuck->GetActuator(ACTUATOR_WHEELS);
	/* Set Prox Sensor */
	m_seProx = (CEpuckProximitySensor *)m_pcEpuck->GetSensor(SENSOR_PROXIMITY);
	/* Set custom light Sensor */
	m_seCustomLightEat = (CCustomLightSensor *)m_pcEpuck->GetSensor(SENSOR_CUSTOM_LIGHT_EAT);
	m_seCustomLightRunAway = (CCustomLightSensor *)m_pcEpuck->GetSensor(SENSOR_CUSTOM_LIGHT_RUNAWAY);
	/* Set light Sensor */
	m_seLight = (CRealLightSensor *)m_pcEpuck->GetSensor(SENSOR_REAL_LIGHT);
	/* Set Blue light Sensor */
	m_seBlueLight = (CRealBlueLightSensor *)m_pcEpuck->GetSensor(SENSOR_REAL_BLUE_LIGHT);
	/* Set Red light Sensor */
	m_seRedLight = (CRealRedLightSensor *)m_pcEpuck->GetSensor(SENSOR_REAL_RED_LIGHT);
	/* Set contact Sensor */
	m_seContact = (CContactSensor *)m_pcEpuck->GetSensor(SENSOR_CONTACT);
	/* Set ground Sensor */
	m_seGround = (CGroundSensor *)m_pcEpuck->GetSensor(SENSOR_GROUND);
	/* Set ground memory Sensor */
	m_seGroundMemory = (CGroundMemorySensor *)m_pcEpuck->GetSensor(SENSOR_GROUND_MEMORY);
	/* Set battery Sensor */
	m_seBattery = (CBatterySensor *)m_pcEpuck->GetSensor(SENSOR_BATTERY);
	m_seCustomBatterySensor = (CCustomBatterySensor *)m_pcEpuck->GetSensor(SENSOR_CUSTOM_BATTERY);
	/* Set blue battery Sensor */
	m_seBlueBattery = (CBlueBatterySensor *)m_pcEpuck->GetSensor(SENSOR_BLUE_BATTERY);
	/* Set red battery Sensor */
	m_seRedBattery = (CRedBatterySensor *)m_pcEpuck->GetSensor(SENSOR_RED_BATTERY);
	/* Set encoder Sensor */
	m_seEncoder = (CEncoderSensor *)m_pcEpuck->GetSensor(SENSOR_ENCODER);
	m_seEncoder->InitEncoderSensor(m_pcEpuck);
	/* Set compass Sensor */
	m_seCompass = (CCompassSensor *)m_pcEpuck->GetSensor(SENSOR_COMPASS);
}

/******************************************************************************/
/******************************************************************************/

baseRobot::~baseRobot()
{
	printf("DASDASDASDASD");
	if (arenaMap != nullptr)
		delete arenaMap;
	if (starA != nullptr)
		delete starA;
}

/******************************************************************************/
/******************************************************************************/

void baseRobot::setPreyColor(light_color_t color)
{
	preyColor = color;
	m_seCustomLightEat->SetColor(preyColor);
	m_seCustomBatterySensor->SetColor(preyColor);
}

void baseRobot::setHunterColor(light_color_t color)
{
	hunterColor = color;
	m_seCustomLightRunAway->SetColor(hunterColor);
}

double baseRobot::getTargetAngle(int size, double *data, const double *directions, double *max)
{
	*max = 0.0;
	double x, y = 0.0;

	/* Calc vector Sum */
	for (int i = 0; i < size; i++)
	{
		x += data[i] * cos(directions[i]);
		y += data[i] * sin(directions[i]);

		if (data[i] > *max)
			*max = data[i];
	}

	/* Calc pointing angle */
	return normalizeAngle(atan2(y, x));
}

void baseRobot::CalcPosition()
{
	double *encoder = m_seEncoder->GetSensorReading(m_pcEpuck);
	double *compass = m_seCompass->GetSensorReading(m_pcEpuck);
	double leftDelta = encoder[0];
	double rightDelta = encoder[1];
	double heading = compass[0];
	//In case that the difference between right and left is less than 1um
	//we consider that the robot is going straight
	if (fabs(leftDelta - rightDelta) < 1.0e-6)
	{ // basically going straight
		//Simple polar equations
		pos.x += leftDelta * cos(heading);
		pos.y += rightDelta * sin(heading);
		pos.orientation = heading;
	}
	else
	{
		// Default Case:
		// Our robot is doing an arc
		double R = CEpuck::WHEELS_DISTANCE * (leftDelta + rightDelta) / (2 * (rightDelta - leftDelta));
		double wd = (rightDelta - leftDelta) / CEpuck::WHEELS_DISTANCE;

		pos.x += R * sin(wd + heading) - R * sin(heading);
		pos.y += -R * cos(wd + heading) + R * cos(heading);
		pos.orientation = normalizeAngle(heading + wd);
	}
	//Normalize the angle to be between 0 and two pi
}

void baseRobot::moveSelfLight()
{
	dVector2 position;
	m_pcEpuck->GetPosition(&position.x, &position.y);
	robotLight->SetCenter(position);
}

utilities::wheelSpeed_t baseRobot::coordinateTasks(std::vector<robotState_t> *robotTasks)
{
	utilities::wheelSpeed_t wheelSpeed = {0.0, 0.0};
	if (dieInhibitor || eating)
	{
		return wheelSpeed;
	}
	double x = 0.0;
	double y = 0.0;
	double angle = 0.0;
	for (robotState_t currentTask : *robotTasks)
	{
		if (currentTask.active)
		{
			x += currentTask.priority * cos(currentTask.direction);
			y += currentTask.priority * sin(currentTask.direction);
		}
	}

	angle = atan2(y, x);

	if (angle > 0)
	{
		wheelSpeed.left = robotSpeed * cos(angle);
		wheelSpeed.right = robotSpeed;
	}
	else
	{
		wheelSpeed.left = robotSpeed;
		wheelSpeed.right = robotSpeed * cos(angle);
	}

	return wheelSpeed;
}

double baseRobot::normalizeAngle(double angle)
{
	while (angle < 0)
	{
		angle += 2 * M_PI;
	}
	while (angle > 2 * M_PI)
	{
		angle -= 2 * M_PI;
	}
	return angle;
}

void baseRobot::promediatePriorities(std::vector<robotState_t> *robotTasks)
{
	double totalPriority = 0;
	for (robotState_t currentState : *robotTasks)
	{
		totalPriority += currentState.priority;
	}
	for (robotState_t currentState : *robotTasks)
	{
		currentState.priority /= totalPriority;
	}
}

void baseRobot::SimulationStep(unsigned n_step_number, double f_time, double f_step_interval)
{
#ifdef DEBUG
	/* FASE 1: LECTURA DE SENSORES */

	/* Leer Sensores de Contacto */
	double *contact = m_seContact->GetSensorReading(m_pcEpuck);
	/* Leer Sensores de Proximidad */
	double *prox = m_seProx->GetSensorReading(m_pcEpuck);
	/* Leer Sensores de Luz */
	double *light = m_seLight->GetSensorReading(m_pcEpuck);
	/* Leer Sensores de Luz Azul*/
	double *bluelight = m_seBlueLight->GetSensorReading(m_pcEpuck);
	/* Leer Sensores de Luz Roja*/
	double *redlight = m_seRedLight->GetSensorReading(m_pcEpuck);
	/* Leer Sensores de Suelo */
	double *ground = m_seGround->GetSensorReading(m_pcEpuck);
	/* Leer Sensores de Suelo Memory */
	double *groundMemory = m_seGroundMemory->GetSensorReading(m_pcEpuck);
	/* Leer Battery Sensores de Suelo Memory */
	double *battery = m_seBattery->GetSensorReading(m_pcEpuck);
	/* Leer Blue Battery Sensores de Suelo Memory */
	double *bluebattery = m_seBlueBattery->GetSensorReading(m_pcEpuck);
	/* Leer Red Battery Sensores de Suelo Memory */
	double *redbattery = m_seRedBattery->GetSensorReading(m_pcEpuck);
	/* Leer Encoder */
	double *encoder = m_seEncoder->GetSensorReading(m_pcEpuck);
	/* Leer Compass */
	double *compass = m_seCompass->GetSensorReading(m_pcEpuck);
#endif
	std::vector<robotState_t> robotTasks;
	/* FASE 2: CONTROLADOR */
	moveSelfLight();
	CalcPosition();
	if (!dieInhibitor)
		FillMap();
	robotTasks.push_back(Avoid());
	robotTasks.push_back(RunAway());
	robotTasks.push_back(Hunt());
	robotTasks.push_back(Navigate());
	robotTasks.push_back(Explore());
	checkDied();
	Eat();
	promediatePriorities(&robotTasks);

	utilities::wheelSpeed_t wheelSpeed = coordinateTasks(&robotTasks);

#ifdef DEBUG
	/* Inicio Incluir las ACCIONES/CONTROLADOR a implementar */
	printf("CONTACT: ");
	for (int i = 0; i < m_seContact->GetNumberOfInputs(); i++)
	{
		printf("%1.3f ", contact[i]);
	}
	printf("\n");

	printf("PROX: ");
	for (int i = 0; i < m_seProx->GetNumberOfInputs(); i++)
	{
		printf("%1.3f ", prox[i]);
	}
	printf("\n");

	printf("LIGHT: ");
	for (int i = 0; i < m_seLight->GetNumberOfInputs(); i++)
	{
		printf("%1.3f ", light[i]);
	}
	printf("\n");

	printf("BLUE LIGHT: ");
	for (int i = 0; i < m_seBlueLight->GetNumberOfInputs(); i++)
	{
		printf("%1.3f ", bluelight[i]);
	}
	printf("\n");

	printf("RED LIGHT: ");
	for (int i = 0; i < m_seRedLight->GetNumberOfInputs(); i++)
	{
		printf("%1.3f ", redlight[i]);
	}
	printf("\n");

	printf("GROUND: ");
	for (int i = 0; i < m_seGround->GetNumberOfInputs(); i++)
	{
		printf("%1.3f ", ground[i]);
	}
	printf("\n");

	printf("GROUND MEMORY: ");
	for (int i = 0; i < m_seGroundMemory->GetNumberOfInputs(); i++)
	{
		printf("%1.3f ", groundMemory[i]);
	}
	printf("\n");

	printf("BATTERY: ");
	for (int i = 0; i < m_seBattery->GetNumberOfInputs(); i++)
	{
		printf("%1.3f ", battery[i]);
	}
	printf("\n");

	printf("BLUE BATTERY: ");
	for (int i = 0; i < m_seBlueBattery->GetNumberOfInputs(); i++)
	{
		printf("%1.3f ", bluebattery[i]);
	}
	printf("\n");
	printf("RED BATTERY: ");
	for (int i = 0; i < m_seRedBattery->GetNumberOfInputs(); i++)
	{
		printf("%1.3f ", redbattery[i]);
	}
	printf("\n");

	printf("ENCODER: ");
	for (int i = 0; i < m_seEncoder->GetNumberOfInputs(); i++)
	{
		printf("%1.5f ", encoder[i]);
	}
	printf("\n");

	printf("COMPASS: ");
	for (int i = 0; i < m_seCompass->GetNumberOfInputs(); i++)
	{
		printf("%1.5f ", compass[i]);
	}
	printf("\n");

	/* Fin: Incluir las ACCIONES/CONTROLADOR a implementar */

	FILE *filePosition = fopen("outputFiles/robotPosition", "a");
	fprintf(filePosition, " %2.4f %2.4f %2.4f %2.4f\n",
			f_time, m_pcEpuck->GetPosition().x,
			m_pcEpuck->GetPosition().y,
			m_pcEpuck->GetRotation());
	fclose(filePosition);
#endif
	char epucklabel[10];
	m_pcEpuck->GetLabel(epucklabel);

	//WriteToFile
	if(!dieInhibitor){
		char pathFile[100] = "outputFiles/bateria_";
		strcat(pathFile, epucklabel);
		//printf(pathFile);  
		FILE *filePosition = fopen(pathFile, "a");
		fprintf(filePosition, " %2.4f %2.4f \n",
				f_time, m_seCustomBatterySensor->GetBatteryLevel());
		fclose(filePosition);
	}

	/* Fase 3: ACTUACIÓN */
	/* Option 1: Speed between -1000, 1000*/

	double fMaxProx = 0.0;
	double *light = m_seCustomLightEat->GetSensorReading(m_pcEpuck);
	const double *lightDirections = m_seCustomLightEat->GetSensorDirections();
	double battery = m_seCustomBatterySensor->GetBatteryLevel();
	double angle = getTargetAngle(m_seCustomLightEat->GetNumberOfInputs(), light, lightDirections, &fMaxProx);

	// if(epucklabel[0] == 'P' && epucklabel[1] == '0'){
	// 	cout << "----P1----" << endl;
	// 	cout << "P1 beteria " << this->m_seCustomBatterySensor->GetBatteryLevel() << endl;
	// 	cout << "Speed left: " << wheelSpeed.left << " Speed right" << wheelSpeed.right << endl;
	// 	cout << "Has Hunted " << hasHunted << " Eating " << eating << " Died " << dieInhibitor << " Nav" << navigating << "Nav step " << navigationStep << endl;
	// 	/*cout << "Sensor read ";
	// 	for(int sindex = 0; sindex < m_seCustomLightEat->GetNumberOfInputs(); sindex++){
	// 		cout << "light " << sindex << " : " << light[sindex] << " - ";
	// 	}
	// 	cout << endl;*/
	// 	for (auto tsk : robotTasks)
	// 	{
	// 		PRINT_ROBOT_STATE(tsk);
	// 	}
	// 	cout << "Map x size " << arenaMap->GetXMax() << " y size " << arenaMap->GetYMax() << endl;
	// 	//arenaMap->PrintMap();
	// 	cout << "---- END P1----" << endl;
	// }

	if (epucklabel[0] == 'C')
	{
		cout << "----CARNACA----" << endl;
		cout << "Carnaca beteria " << this->m_seCustomBatterySensor->GetBatteryLevel() << endl;
		cout << "Speed left: " << wheelSpeed.left << " Speed right" << wheelSpeed.right << endl;
		cout << "Has Hunted " << hasHunted << " Eating " << eating << " Died " << dieInhibitor << endl;
		/*cout << "Sensor read ";
		for(int sindex = 0; sindex < m_seCustomLightEat->GetNumberOfInputs(); sindex++){
			cout << "light " << sindex << " : " << light[sindex] << " - ";
		}
		cout << endl;*/
		for (auto tsk : robotTasks)
		{
			PRINT_ROBOT_STATE(tsk);
		}
		cout << "Map x size " << arenaMap->GetXMax() << " y size " << arenaMap->GetYMax() << endl;
		//arenaMap->PrintMap();
		cout << "---- END CARNACA----" << endl;
	} else if(epucklabel[0] == 'H'){
		cout << "----VEGANO----" << endl;
		cout << "Vegano beteria " << this->m_seCustomBatterySensor->GetBatteryLevel() << endl;

		cout << "Speed left: " << wheelSpeed.left << " Speed right" << wheelSpeed.right << endl;
		cout << "Has Hunted " << hasHunted << " Eating " << eating << " Died " << dieInhibitor << endl;
		/*cout << "Sensor read ";
		for(int sindex = 0; sindex < m_seCustomLightEat->GetNumberOfInputs(); sindex++){
			cout << "light " << sindex << " : " << light[sindex] << " - ";
		}
		cout << endl;*/
		for(auto tsk : robotTasks)
		{
			PRINT_ROBOT_STATE(tsk);
		}
		//arenaMap->PrintMap();
		cout << "Map x size "  << arenaMap->GetXMax() << " y size "<<arenaMap->GetYMax() << endl;
		cout << "---- END VEGANO----" << endl;
	}
	m_seCustomBatterySensor->hasMoved(!(wheelSpeed.left == 0 && wheelSpeed.right == 0));
	m_acWheels->SetSpeed(wheelSpeed.left, wheelSpeed.right);
	/* Option 2: Speed between 0,1*/
	//m_acWheels->SetOutput(0,0.5);
	//m_acWheels->SetOutput(1,0.5);
}

/******************************************************************************/
/******************************************************************************/
//Tasks functions

robotState_t baseRobot::Avoid()
{
	/* Leer Sensores de Proximidad */
	double *prox = m_seProx->GetSensorReading(m_pcEpuck);
	double fMaxProx = 0.0;
	const double *proxDirections = m_seProx->GetSensorDirections();

	double angle = getTargetAngle(m_seProx->GetNumberOfInputs(), prox, proxDirections, &fMaxProx) - M_PI;

	robotState_t state;
	state.direction = angle;
	state.active = false;
	state.priority = 2.0; //To be defined
	/* If above a threshold */
	if (fMaxProx > proximitySensorThreshold)
	{
		state.active = true;
	}
	return state;
}

robotState_t baseRobot::Hunt()
{
	double fMaxProx = 0.0;
	double *light = m_seCustomLightEat->GetSensorReading(m_pcEpuck);
	const double *lightDirections = m_seCustomLightEat->GetSensorDirections();
	double battery = m_seCustomBatterySensor->GetBatteryLevel();
	double angle = getTargetAngle(m_seCustomLightEat->GetNumberOfInputs(), light, lightDirections, &fMaxProx);

	robotState_t state;
	state.direction = angle;
	state.active = true;
	state.priority = 1.0; //To be defined
	hasHunted = false;
	/* If above a threshold */
	//if (fMaxProx > proximitySensorThreshold)
	char epucklabel[10];
	m_pcEpuck->GetLabel(epucklabel);
	if (fMaxProx > checkDiedThreshold)
	{
		hasHunted = true;
	}
	if (runAwayInhibitor || (battery > huntThreshold) || eating)
	{
		state.active = false;
		hasHunted = false;
	}
	return state;
}

robotState_t baseRobot::Explore()
{
	return {true, 0, 1};
}

robotState_t baseRobot::RunAway()
{
	double fMaxProx = 0.0;
	double *light = m_seCustomLightRunAway->GetSensorReading(m_pcEpuck);
	const double *lightDirections = m_seCustomLightRunAway->GetSensorDirections();

	double angle = getTargetAngle(m_seCustomLightRunAway->GetNumberOfInputs(), light, lightDirections, &fMaxProx);

	robotState_t state;
	state.direction = angle - M_PI;
	state.active = false;
	state.priority = 3.0; //To be defined
	runAwayInhibitor = false;
	/* If above a threshold */
	if (fMaxProx > runAwayThreshold)
	{
		state.active = true;
		runAwayInhibitor = true;
	}
	return state;
}

robotState_t baseRobot::Navigate()
{
	if (target != nullptr && !navigating)
	{
		//Hago estrellla
		starA = new AuxAlgorithms::AStar(arenaMap);
		navigating = true;
		//Get Myself
		navigationStep = 0;
		auto myselfNowTmp = arenaMap->GetObjectsPositions(MYSELF)[0];
		path = starA->aStarSearch(myselfNowTmp, *target);
		target = nullptr;
	}
	if (!navigating)
	{
		return {false, 0, 0};
	}

	double dx,dy;
	dx = path[navigationStep].first - pos.x;
	dy = path[navigationStep].second - pos.y;
	char epucklabel[10];
	m_pcEpuck->GetLabel(epucklabel);
	if(epucklabel[0] == 'P' && epucklabel[1] == '0'){
		printf("Punto Gordo: %f %f \n",dx,dy);
	}
	if(fabs(dx) > arenaMap->GetStep() && fabs(dy) > arenaMap->GetStep()){
		navigationStep++;
		if(navigationStep == path.size()-1){
			navigating = false;
			delete target;
			target = nullptr;
			hasHunted = true;
			printf("HE LLEGADO \n");
			printf("HE LLEGADO \n");
			printf("HE LLEGADO \n");
			printf("HE LLEGADO \n");
			return {false, 0, 0};
		}
		dx = path[navigationStep].first - pos.x;
		dy = path[navigationStep].second - pos.y;
	}
	double angle = m_seCompass->GetSensorReading(m_pcEpuck)[0] - atan2(dy,dx);
	return {true, angle, 3};
}

bool baseRobot::CheckPredatorDistance()
{
	double fMaxProx = 0.0;
	char epucklabel[10];
	m_pcEpuck->GetLabel(epucklabel);
	double *light = m_seCustomLightRunAway->GetSensorReading(m_pcEpuck);
	const double *lightDirections = m_seCustomLightRunAway->GetSensorDirections();
	getTargetAngle(m_seCustomLightRunAway->GetNumberOfInputs(), light, lightDirections, &fMaxProx);
	/*if(epucklabel[0] == 'H'){
		cout << "HERB MUERE " << fMaxProx << endl;	
	}*/
	return (fMaxProx > checkDiedThreshold - DIE_ERROR);
}

bool baseRobot::CheckBattery()
{
	double battery = m_seCustomBatterySensor->GetBatteryLevel();
	return (battery == 0);
}

void baseRobot::checkDied()
{
	dieInhibitor |= CheckBattery() || CheckPredatorDistance();
}

void baseRobot::Eat()
{
	double battery = m_seCustomBatterySensor->GetBatteryLevel();

	if (hasHunted)
	{
		eating = true;
	}
	if (runAwayInhibitor || (battery > eatThreshold))
	{
		eating = false;
	}
}

/******************************************
 * ****************************************/

void baseRobot::FillMap()
{
	char epucklabel[10];
	m_pcEpuck->GetLabel(epucklabel);
	/*if(epucklabel[0] == 'C'){
		cout << "BEGIN MAP " << epucklabel << endl;
	}*/
	//printf("LLEGO SDHUASD %s",epucklabel);
	double *prox = m_seProx->GetSensorReading(m_pcEpuck);
	double *light = m_seCustomLightEat->GetSensorReading(m_pcEpuck);
	double fMaxProx = 0.0;
	const double *proxDirections = m_seProx->GetSensorDirections();
	const double *lightDirections = m_seCustomLightEat->GetSensorDirections();
	vector<double> distanceReadings;
	vector<double> absoluteSensorAngle;
	double absDistance = 0;
	double absAngle = 0;
	double incX, incY;
	int incXDiscrete, incYDiscrete, posSelfx, posSelfy;
	box_t detection;
	std::vector<std::pair<int, int>> mySelfList = arenaMap->GetObjectsPositions(MYSELF);
	if (mySelfList.size() != 1)
	{
		//arenaMap->PrintMap();
		cout << "ERROR HAY MAS DE UN YO " << mySelfList.size() << endl;
		//return;
	}

	std::pair<int, int> mySelfPosition = mySelfList[0];
	arenaMap->AddBox(mySelfPosition.first, mySelfPosition.second, EMPTY);
	arenaMap->AddBoxAbsolute(pos.x, pos.y, MYSELF);
	if (epucklabel[0] == 'C')
	{
		//printf("PosX: %f, PosY: %f\n", pos.x, pos.y);
		//printf("SELF: %d %d MYSELFOLD %d %d POS %f %f \n",posSelfx,posSelfy,mySelfPosition.first,mySelfPosition.second,pos.x,pos.y);
	}
	//printf("LLEGO SDHUASD %s",epucklabel);

	for (int i = 0; i < m_seProx->GetNumberOfInputs(); i++)
	{
		//Absolute distance
		absDistance = prox[i] * PROXIMITY_MAX_DISTANCE;
		//Absolute angle
		absAngle = proxDirections[i] + m_seCompass->GetSensorReading(m_pcEpuck)[0];
		//RealIncrements
		incX = absDistance * sin(absAngle);
		incY = absDistance * cos(absAngle);
		if (prox[i] == 0.0)
		{
			detection = EMPTY;
		}
		else
		{
			detection = WALL;
		}
		if (epucklabel[0] == 'C')
		{
			//cout << "inc x " << incX << "inc y " << incY << " detec " << detection << endl;
		}
		if (fabs(incX) > arenaMap->GetStep() || fabs(incY) > arenaMap->GetStep())
			arenaMap->AddBoxAbsolute(pos.x + incX, pos.y + incY, detection);
	}

	for (int i = 0; i < m_seCustomLightEat->GetNumberOfInputs(); i++)
	{
		absAngle = lightDirections[i] + m_seCompass->GetSensorReading(m_pcEpuck)[0];
		incX = 2*arenaMap->GetStep() * sin(absAngle);
		incY = 2*arenaMap->GetStep() * cos(absAngle);
		if (light[i] > checkDiedThreshold)
		{
			detection = LIGHT;
		}else{
			continue;
		}
		if (epucklabel[0] == 'C')
		{
			//cout << "inc x " << incX << "inc y " << incY << " detec " << detection << endl;
		}
		arenaMap->AddBoxAbsolute(pos.x + incX, pos.y + incY, detection);
	}

	if (epucklabel[0] == 'C')
	{
		//arenaMap->PrintMap();
	}
	//arenaMap->PrintMap();
}
