#include <stdint.h>
#include <cstdio>
#include <utility>
#include <vector>

namespace dataStructures
{

enum box_t
{
	ERROR,
	UNEXPLORED,
	EMPTY,
	WALL,
	MYSELF,
	OBJECT,
    LIGHT
};

class ArenaMap
{
  private:
	box_t **grid;
	size_t xMax;
	size_t yMax;
	void FillMap(box_t **_grid, size_t x, size_t y);
	box_t **CreateGrid(size_t x, size_t y);
	void DeleteGrid(box_t **grid, size_t y);

  public:
	ArenaMap(const size_t x, const size_t y, double mapStep);
	void AddBox(int x, int y, box_t type);
	void AddBoxAbsolute(double x, double y, box_t type);
	box_t GetBox(size_t x, size_t y);
	void ExpandMap();
	void ExpandMap(const int new_x, const int new_y);
	void PrintMap();
	size_t GetXMax();
	size_t GetYMax();
	double GetStep();

	//x,y
	double mapStep;
	std::pair<int, int> origin;
	std::pair<double, double> GetPositionAbsolute(int x, int y);
	std::vector<std::pair<int, int>> GetObjectsPositions(box_t object);
	std::vector<std::pair<double, double>> GetObjectsPositionsAbsolute(box_t object);
	box_t **GetGrid();
	~ArenaMap();
};

} // namespace dataStructures
