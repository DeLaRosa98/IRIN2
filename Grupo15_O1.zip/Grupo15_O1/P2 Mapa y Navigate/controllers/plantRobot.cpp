/******************* INCLUDES ******************/
/***********************************************/

/******************** General ******************/
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <sys/time.h>
#include <iostream>

/******************** Simulator ****************/
/******************** Sensors ******************/
#include "epuckproximitysensor.h"
#include "contactsensor.h"
#include "reallightsensor.h"
#include "realbluelightsensor.h"
#include "realredlightsensor.h"
#include "groundsensor.h"
#include "groundmemorysensor.h"
#include "batterysensor.h"
#include "bluebatterysensor.h"
#include "redbatterysensor.h"
#include "encodersensor.h"
#include "compasssensor.h"
#include "customlightsensor.h"
#include "custombatterysensor.h"
/******************** Actuators ****************/
#include "wheelsactuator.h"

/******************** Controller **************/
#include "plantRobot.h"

extern gsl_rng* rng;
extern long int rngSeed;

using namespace std;



plantRobotController::plantRobotController (const char *pch_name, CEpuck *pc_epuck, int n_write_to_file, CCustomLightObject *light) : baseRobot (pch_name, pc_epuck, n_write_to_file, light)
{
	this->setPreyColor(CCustomLightObject::yellow());
	this->setHunterColor(CCustomLightObject::blue());
}
robotState_t plantRobotController::Hunt(){
	if(arenaMap->GetObjectsPositions(LIGHT).size() != 0 && !navigating){
		target = new std::pair<int,int>(arenaMap->GetObjectsPositions(LIGHT)[0].first,arenaMap->GetObjectsPositions(LIGHT)[0].second);
		arenaMap->PrintMap();
			char epucklabel[10];
	m_pcEpuck->GetLabel(epucklabel);
		printf("target robot %s \n",epucklabel);
		printf("target %d, %d \n",arenaMap->GetObjectsPositions(LIGHT)[0].first,arenaMap->GetObjectsPositions(LIGHT)[0].second);
	}
	return {false, 0, 0};
}
/******************************************************************************/
/******************************************************************************/

plantRobotController::~plantRobotController()
{
	
}


/******************************************************************************/
/******************************************************************************/

/******************************************************************************/
/******************************************************************************/

