Peta jajajaja porque la fitness no impide que se quede quieto mirando a la luz (arreglo en la 4)
